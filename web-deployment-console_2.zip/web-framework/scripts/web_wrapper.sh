#!/bin/bash
# ============================================================================
# Web Execution Wrapper
# Makes existing shell scripts compatible with web execution
# ============================================================================

# This wrapper is sourced by scripts when executed from the web interface
# It overrides interactive functions to work with WebSocket communication

# Check if running in web mode
if [[ "$WEB_EXECUTION" == "1" ]]; then
    
    # ========================================================================
    # Override interactive functions
    # ========================================================================
    
    # Override verify_continue to auto-continue or wait for WebSocket input
    verify_continue() {
        echo "[WEB_PROMPT] Continue? (Y/N)"
        if [[ -n "$AUTO_CONTINUE" ]]; then
            echo "[AUTO] Continuing automatically..."
            return 0
        fi
        # In web mode, wait for input from WebSocket
        read -r response
        case "$response" in
            [Yy]|[Yy][Ee][Ss]|"")
                return 0
                ;;
            *)
                echo "[USER] Execution cancelled by user"
                exit 1
                ;;
        esac
    }
    
    # Override PROMPT function for web compatibility
    PROMPT() {
        local message="$@"
        echo "[WEB_PROMPT] ${message}"
    }
    
    # Override menu read to work with web input
    web_read_option() {
        local prompt="${1:-Pick an option}"
        echo "[WEB_PROMPT] ${prompt}"
        read -r opt
        echo "$opt"
    }
    
    # ========================================================================
    # Enhanced output functions for web
    # ========================================================================
    
    # Add HTML-friendly output markers
    WEB_SUC() {
        echo -e "\033[32m$1\033[0m"
    }
    
    WEB_FAIL() {
        echo -e "\033[31m$1\033[0m"
    }
    
    WEB_FYI() {
        echo -e "\033[36m$1\033[0m"
    }
    
    WEB_HLT() {
        echo -e "\033[31m$1\033[0m"
    }
    
    # ========================================================================
    # Web-specific logging
    # ========================================================================
    
    web_log() {
        local level="$1"
        local message="$2"
        local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
        echo "[${timestamp}] [${level}] ${message}"
    }
    
    web_log_start() {
        web_log "INFO" "=========================================="
        web_log "INFO" "Script: $0"
        web_log "INFO" "Execution ID: $SCRIPT_EXECUTION_ID"
        web_log "INFO" "Started: $(date)"
        web_log "INFO" "=========================================="
    }
    
    web_log_end() {
        local exit_code="$1"
        web_log "INFO" "=========================================="
        web_log "INFO" "Completed: $(date)"
        web_log "INFO" "Exit Code: $exit_code"
        web_log "INFO" "=========================================="
    }
    
    # ========================================================================
    # Trap for clean exit
    # ========================================================================
    
    trap 'web_log_end $?' EXIT
    
    # Log start
    web_log_start
    
    echo "[WEB_INFO] Running in web execution mode"
fi
