"""
Web-enabled Shell Script Framework
FastAPI Backend with WebSocket support for real-time script execution

Integrates with existing orchestration dashboard architecture.
"""

import asyncio
import json
import os
import pty
import select
import signal
import subprocess
import uuid
from datetime import datetime
from pathlib import Path
from typing import Optional

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, HTMLResponse
from pydantic import BaseModel

# ============================================================================
# Configuration
# ============================================================================

DEPLOYMENT_HOME = os.environ.get("DEPLOYMENT_HOME", "/ADMIN/Oracle/Toolkits/deployStage")
LOG_DIR = Path("./logs")
LOG_DIR.mkdir(exist_ok=True)

# Script registry - defines available scripts organized by tier
SCRIPT_REGISTRY = {
    "appTier": {
        "name": "Application Tier",
        "icon": "🖥️",
        "menus": {
            "preserve": {
                "name": "Preserve & Cleanup",
                "description": "Pre-clone preservation tasks",
                "scripts": {
                    "PS": {"name": "Presave Apps Configurations", "script": "preSaveApps.sh", "confirm": True},
                    "OUD": {"name": "Deregister OUD", "script": "deRegOUD.sh", "confirm": True},
                    "OAM": {"name": "Deregister OAM", "script": "deRegOAM.sh", "confirm": True},
                }
            },
            "restore": {
                "name": "Restore & Prepare",
                "description": "Restore from backup and configure",
                "scripts": {
                    "RS": {"name": "Restore Backup", "script": "restoreEBSApps.sh", "confirm": True},
                    "CFG": {"name": "Run AdcfgClone", "script": "runCfgClone.sh", "confirm": True, "params": ["target_env"]},
                }
            },
            "configure": {
                "name": "Post Clone & Configure",
                "description": "Post-clone configuration tasks",
                "scripts": {
                    "AC": {"name": "Auto Config", "script": "runautocfg.sh", "confirm": False},
                    "AD": {"name": "Start AdminServer", "script": "startAdmServer.sh", "confirm": False},
                    "CF": {"name": "Update Connection Filter", "script": "connFilter.sh", "confirm": False},
                    "PC": {"name": "Pre-Clone", "script": "preClone.sh", "confirm": True},
                    "AS": {"name": "Add Second Node", "script": "addNode.sh", "confirm": True, "remote": True},
                    "PP": {"name": "Post Clone Phase App Tier", "script": "postClone_phase1.sh", "confirm": True},
                    "MS": {"name": "Create MServers (Second Node)", "script": "createMS.sh", "confirm": True, "remote": True},
                    "OHS": {"name": "Configure OHS (both nodes)", "script": "confOHS.sh", "confirm": True},
                    "OUD_REG": {"name": "Register OUD", "script": "oudRegister.sh", "confirm": True},
                    "OAM_REG": {"name": "Register OAM", "script": "oamRegister.sh", "confirm": True},
                    "AG": {"name": "Deploy Access Gate Servers", "script": "deployAG.sh", "confirm": True},
                    "TLS": {"name": "Configure TLS oacore/oaea Servers", "script": "configureTLSAll.sh", "confirm": True},
                }
            }
        }
    },
    "dbTier": {
        "name": "Database Tier",
        "icon": "🗄️",
        "menus": {
            "presave": {
                "name": "PreSave & Drop",
                "description": "Database preservation and cleanup",
                "scripts": {
                    "PRE": {"name": "Preserve Existing DB Configurations", "script": "preSave.sh", "confirm": True},
                    "DRP": {"name": "Drop Database", "script": "dropDB.sh", "confirm": True, "dangerous": True},
                    "BIN": {"name": "Clone DB Binaries", "script": "dbHomeClone.sh", "confirm": True},
                }
            },
            "clone": {
                "name": "Database Cloning",
                "description": "Duplicate and configure database",
                "scripts": {
                    "DUP": {"name": "Duplicate Database", "script": "duplicateDB.sh", "confirm": True},
                    "REN": {"name": "Rename PDB", "script": "renamePDB.sh", "confirm": True},
                    "RES": {"name": "Reset Passwords (DB)", "script": "resetPass.sh", "confirm": True},
                    "TDE": {"name": "Update TDE", "script": "updateTDE.sh", "confirm": True},
                    "LIS": {"name": "Create Listener", "script": "createListener.sh", "confirm": True},
                }
            },
            "configure": {
                "name": "Post-Clone Configuration",
                "description": "Database configuration tasks",
                "scripts": {
                    "CTX": {"name": "Create Context File", "script": "createDBContext.sh", "confirm": True},
                    "UTL": {"name": "Update UTL File", "script": "updateUtlFile.sh", "confirm": True},
                    "ACG": {"name": "Run Autoconfig", "script": "autoCfg.sh", "confirm": True, "params": ["mode"]},
                    "ADD": {"name": "Add Second Node", "script": "addNodeAutoCfg.sh", "confirm": True, "remote": True},
                    "RMN": {"name": "Update RMAN Configuration", "script": "updateRMAN.sh", "confirm": True},
                }
            }
        }
    }
}

# ============================================================================
# Application Setup
# ============================================================================

app = FastAPI(
    title="Shell Script Web Framework",
    description="Web interface for Oracle EBS deployment scripts",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount static files
app.mount("/static", StaticFiles(directory="frontend"), name="static")

# Active script executions
active_executions: dict = {}


# ============================================================================
# Pydantic Models
# ============================================================================

class ScriptExecutionRequest(BaseModel):
    tier: str
    menu: str
    script_id: str
    params: dict = {}
    environment: dict = {}


class ScriptResponse(BaseModel):
    execution_id: str
    status: str
    message: str


class PromptResponse(BaseModel):
    execution_id: str
    response: str


# ============================================================================
# Script Execution Engine
# ============================================================================

class ScriptExecutor:
    """Handles script execution with PTY for interactive support"""
    
    def __init__(self, execution_id: str, tier: str, script_path: str, 
                 params: dict = None, environment: dict = None):
        self.execution_id = execution_id
        self.tier = tier
        self.script_path = script_path
        self.params = params or {}
        self.environment = environment or {}
        self.process = None
        self.master_fd = None
        self.slave_fd = None
        self.output_buffer = []
        self.status = "pending"
        self.log_file = None
        self.html_log_file = None
        self.pending_prompts = asyncio.Queue()
        self.websocket = None
        
    def _setup_environment(self) -> dict:
        """Setup execution environment with all required variables"""
        env = os.environ.copy()
        env["DEPLOYMENT_HOME"] = DEPLOYMENT_HOME
        env["TERM"] = "xterm-256color"
        env["COLUMNS"] = "120"
        env["LINES"] = "40"
        
        # Add custom environment variables
        env.update(self.environment)
        
        # Disable interactive prompts for web execution
        env["WEB_EXECUTION"] = "1"
        env["SCRIPT_EXECUTION_ID"] = self.execution_id
        
        return env
    
    def _create_log_files(self):
        """Create text and HTML log files"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        base_name = f"{self.tier}_{Path(self.script_path).stem}_{timestamp}"
        
        self.log_file = LOG_DIR / f"{base_name}.log"
        self.html_log_file = LOG_DIR / f"{base_name}.html"
        
        # Initialize HTML log
        with open(self.html_log_file, 'w') as f:
            f.write(f"""<!DOCTYPE html>
<html>
<head>
    <title>Execution Log - {self.execution_id}</title>
    <style>
        body {{ 
            background: #0a1628; 
            color: #e0e6ed; 
            font-family: 'Consolas', 'Monaco', monospace; 
            padding: 20px;
            line-height: 1.6;
        }}
        .header {{ 
            color: #00d4ff; 
            border-bottom: 2px solid #00d4ff; 
            padding-bottom: 10px;
            margin-bottom: 20px;
        }}
        .timestamp {{ color: #6b7280; font-size: 0.85em; }}
        .success {{ color: #10b981; }}
        .error {{ color: #ef4444; }}
        .info {{ color: #00d4ff; }}
        .warning {{ color: #f59e0b; }}
        .output {{ 
            background: #111827; 
            padding: 15px; 
            border-radius: 8px; 
            white-space: pre-wrap;
            overflow-x: auto;
        }}
        .prompt {{ 
            background: #1e3a5f; 
            padding: 10px; 
            border-left: 4px solid #00d4ff;
            margin: 10px 0;
        }}
    </style>
</head>
<body>
    <div class="header">
        <h1>Execution Log</h1>
        <p>ID: {self.execution_id}</p>
        <p>Script: {self.script_path}</p>
        <p>Started: {datetime.now().isoformat()}</p>
    </div>
    <div class="output">
""")
    
    def _append_to_logs(self, text: str, log_type: str = "output"):
        """Append text to both log files"""
        # Text log
        with open(self.log_file, 'a') as f:
            f.write(text)
        
        # HTML log with styling
        html_text = self._ansi_to_html(text)
        css_class = {
            "output": "",
            "success": "success",
            "error": "error", 
            "info": "info",
            "prompt": "prompt"
        }.get(log_type, "")
        
        with open(self.html_log_file, 'a') as f:
            if css_class:
                f.write(f'<span class="{css_class}">{html_text}</span>')
            else:
                f.write(html_text)
    
    def _ansi_to_html(self, text: str) -> str:
        """Convert ANSI color codes to HTML spans"""
        import re
        import html
        
        # Escape HTML
        text = html.escape(text)
        
        # ANSI to HTML color mapping
        ansi_colors = {
            '31': 'color: #ef4444',  # Red
            '32': 'color: #10b981',  # Green
            '33': 'color: #f59e0b',  # Yellow
            '34': 'color: #3b82f6',  # Blue
            '35': 'color: #8b5cf6',  # Magenta
            '36': 'color: #00d4ff',  # Cyan
            '37': 'color: #e0e6ed',  # White
            '0': '',  # Reset
        }
        
        # Replace ANSI codes with HTML spans
        pattern = r'\x1b\[(\d+)m'
        
        def replace_ansi(match):
            code = match.group(1)
            if code == '0':
                return '</span>'
            style = ansi_colors.get(code, '')
            if style:
                return f'<span style="{style}">'
            return ''
        
        text = re.sub(pattern, replace_ansi, text)
        return text
    
    def _finalize_html_log(self):
        """Close HTML log file properly"""
        with open(self.html_log_file, 'a') as f:
            f.write(f"""
    </div>
    <div class="header" style="margin-top: 20px; border-top: 2px solid #00d4ff; border-bottom: none;">
        <p>Completed: {datetime.now().isoformat()}</p>
        <p>Status: <span class="{'success' if self.status == 'completed' else 'error'}">{self.status}</span></p>
    </div>
</body>
</html>""")

    async def execute(self, websocket: WebSocket):
        """Execute the script with real-time output streaming"""
        self.websocket = websocket
        self.status = "running"
        self._create_log_files()
        
        try:
            # Create pseudo-terminal for interactive scripts
            self.master_fd, self.slave_fd = pty.openpty()
            
            # Build the command
            cmd = self._build_command()
            env = self._setup_environment()
            
            await self._send_message("info", f"Starting execution: {self.script_path}")
            await self._send_message("info", f"Log file: {self.log_file}")
            
            # Start the process
            self.process = subprocess.Popen(
                cmd,
                stdin=self.slave_fd,
                stdout=self.slave_fd,
                stderr=self.slave_fd,
                env=env,
                shell=True,
                preexec_fn=os.setsid
            )
            
            # Close slave fd in parent
            os.close(self.slave_fd)
            
            # Read output in real-time
            await self._stream_output()
            
            # Wait for process to complete
            self.process.wait()
            
            if self.process.returncode == 0:
                self.status = "completed"
                await self._send_message("success", "Script completed successfully")
            else:
                self.status = "failed"
                await self._send_message("error", f"Script failed with exit code: {self.process.returncode}")
                
        except Exception as e:
            self.status = "error"
            await self._send_message("error", f"Execution error: {str(e)}")
            
        finally:
            self._finalize_html_log()
            if self.master_fd:
                os.close(self.master_fd)
            
            await self._send_message("complete", json.dumps({
                "status": self.status,
                "log_file": str(self.log_file),
                "html_log_file": str(self.html_log_file)
            }))
    
    def _build_command(self) -> str:
        """Build the shell command with proper sourcing"""
        tier_dir = "appTier" if self.tier == "appTier" else "dbTier"
        
        # Build param string
        param_str = " ".join(str(v) for v in self.params.values()) if self.params else ""
        
        cmd = f"""
        export DEPLOYMENT_HOME="{DEPLOYMENT_HOME}"
        source "{DEPLOYMENT_HOME}/common/bin/commEnv"
        source "{DEPLOYMENT_HOME}/{tier_dir}/bin/{tier_dir[:-4]}Var.sh" 2>/dev/null || true
        cd "{DEPLOYMENT_HOME}/{tier_dir}/bin"
        . ./{self.script_path} {param_str}
        """
        
        return f"bash -c '{cmd}'"
    
    async def _stream_output(self):
        """Stream output from PTY to WebSocket"""
        loop = asyncio.get_event_loop()
        
        while True:
            # Check if process is still running
            if self.process.poll() is not None:
                # Read any remaining output
                try:
                    while True:
                        ready, _, _ = select.select([self.master_fd], [], [], 0.1)
                        if ready:
                            data = os.read(self.master_fd, 1024)
                            if data:
                                text = data.decode('utf-8', errors='replace')
                                self.output_buffer.append(text)
                                self._append_to_logs(text)
                                await self._send_message("output", text)
                        else:
                            break
                except:
                    pass
                break
            
            # Check for available output
            ready, _, _ = select.select([self.master_fd], [], [], 0.1)
            
            if ready:
                try:
                    data = os.read(self.master_fd, 1024)
                    if data:
                        text = data.decode('utf-8', errors='replace')
                        self.output_buffer.append(text)
                        self._append_to_logs(text)
                        await self._send_message("output", text)
                        
                        # Check for prompts that need user input
                        if self._detect_prompt(text):
                            await self._handle_prompt(text)
                except OSError:
                    break
            
            await asyncio.sleep(0.05)
    
    def _detect_prompt(self, text: str) -> bool:
        """Detect if output contains a prompt requiring input"""
        prompt_patterns = [
            "Pick up an option",
            "Continue? (Y/N)",
            "Press Enter to continue",
            "Enter password",
            "verify_continue",
            "(Y/N)",
            "(y/n)",
            ":\c",  # Common prompt ending in scripts
        ]
        return any(pattern.lower() in text.lower() for pattern in prompt_patterns)
    
    async def _handle_prompt(self, prompt_text: str):
        """Handle interactive prompts"""
        await self._send_message("prompt", prompt_text)
        self._append_to_logs(prompt_text, "prompt")
        
        # Wait for response from WebSocket
        try:
            response = await asyncio.wait_for(
                self.pending_prompts.get(),
                timeout=300  # 5 minute timeout
            )
            
            # Send response to process
            os.write(self.master_fd, (response + "\n").encode())
            self._append_to_logs(f"\n[User Input]: {response}\n", "info")
            
        except asyncio.TimeoutError:
            await self._send_message("error", "Prompt timeout - no response received")
            self.terminate()
    
    async def send_input(self, text: str):
        """Send input to the running process"""
        if self.master_fd:
            os.write(self.master_fd, (text + "\n").encode())
            await self.pending_prompts.put(text)
    
    async def _send_message(self, msg_type: str, content: str):
        """Send message to WebSocket"""
        if self.websocket:
            try:
                await self.websocket.send_json({
                    "type": msg_type,
                    "content": content,
                    "timestamp": datetime.now().isoformat(),
                    "execution_id": self.execution_id
                })
            except:
                pass
    
    def terminate(self):
        """Terminate the running process"""
        if self.process:
            try:
                os.killpg(os.getpgid(self.process.pid), signal.SIGTERM)
            except:
                pass
            self.status = "terminated"


# ============================================================================
# API Routes
# ============================================================================

@app.get("/")
async def root():
    """Serve the main dashboard"""
    return FileResponse("frontend/index.html")


@app.get("/api/registry")
async def get_registry():
    """Get the complete script registry"""
    return SCRIPT_REGISTRY


@app.get("/api/tier/{tier}")
async def get_tier_scripts(tier: str):
    """Get scripts for a specific tier"""
    if tier not in SCRIPT_REGISTRY:
        raise HTTPException(status_code=404, detail=f"Tier '{tier}' not found")
    return SCRIPT_REGISTRY[tier]


@app.get("/api/logs")
async def list_logs(limit: int = Query(default=50, le=100)):
    """List recent execution logs"""
    logs = []
    for log_file in sorted(LOG_DIR.glob("*.html"), reverse=True)[:limit]:
        stats = log_file.stat()
        logs.append({
            "filename": log_file.name,
            "path": str(log_file),
            "size": stats.st_size,
            "modified": datetime.fromtimestamp(stats.st_mtime).isoformat()
        })
    return logs


@app.get("/api/logs/{filename}")
async def get_log(filename: str):
    """Get a specific log file"""
    log_path = LOG_DIR / filename
    if not log_path.exists():
        raise HTTPException(status_code=404, detail="Log file not found")
    
    if filename.endswith('.html'):
        return FileResponse(log_path, media_type="text/html")
    return FileResponse(log_path, media_type="text/plain")


@app.post("/api/execute")
async def start_execution(request: ScriptExecutionRequest) -> ScriptResponse:
    """Start a script execution (returns execution ID for WebSocket connection)"""
    execution_id = str(uuid.uuid4())[:8]
    
    # Validate tier and script
    if request.tier not in SCRIPT_REGISTRY:
        raise HTTPException(status_code=400, detail=f"Invalid tier: {request.tier}")
    
    tier_config = SCRIPT_REGISTRY[request.tier]
    if request.menu not in tier_config["menus"]:
        raise HTTPException(status_code=400, detail=f"Invalid menu: {request.menu}")
    
    menu_config = tier_config["menus"][request.menu]
    if request.script_id not in menu_config["scripts"]:
        raise HTTPException(status_code=400, detail=f"Invalid script: {request.script_id}")
    
    script_config = menu_config["scripts"][request.script_id]
    
    return ScriptResponse(
        execution_id=execution_id,
        status="ready",
        message=f"Ready to execute {script_config['name']}. Connect to WebSocket /ws/{execution_id} to start."
    )


@app.websocket("/ws/{execution_id}")
async def websocket_endpoint(websocket: WebSocket, execution_id: str):
    """WebSocket endpoint for script execution"""
    await websocket.accept()
    
    try:
        # Wait for execution request
        data = await websocket.receive_json()
        
        if data.get("action") == "execute":
            tier = data.get("tier")
            menu = data.get("menu")
            script_id = data.get("script_id")
            params = data.get("params", {})
            environment = data.get("environment", {})
            
            # Get script configuration
            script_config = SCRIPT_REGISTRY[tier]["menus"][menu]["scripts"][script_id]
            
            # Create executor
            executor = ScriptExecutor(
                execution_id=execution_id,
                tier=tier,
                script_path=script_config["script"],
                params=params,
                environment=environment
            )
            
            active_executions[execution_id] = executor
            
            # Start execution
            await executor.execute(websocket)
            
        elif data.get("action") == "input":
            # Handle user input for prompts
            if execution_id in active_executions:
                await active_executions[execution_id].send_input(data.get("text", ""))
                
        elif data.get("action") == "terminate":
            # Terminate execution
            if execution_id in active_executions:
                active_executions[execution_id].terminate()
                await websocket.send_json({
                    "type": "terminated",
                    "content": "Execution terminated by user"
                })
                
    except WebSocketDisconnect:
        if execution_id in active_executions:
            active_executions[execution_id].terminate()
    finally:
        if execution_id in active_executions:
            del active_executions[execution_id]


@app.get("/api/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "deployment_home": DEPLOYMENT_HOME,
        "active_executions": len(active_executions)
    }


# ============================================================================
# Run Application
# ============================================================================

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8080)
