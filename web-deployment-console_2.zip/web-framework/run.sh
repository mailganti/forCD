#!/bin/bash
# ============================================================================
# Oracle EBS Deployment Console - Setup and Run Script
# ============================================================================

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV_DIR="${SCRIPT_DIR}/venv"
PORT="${PORT:-8080}"
HOST="${HOST:-0.0.0.0}"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
NC='\033[0m'

print_header() {
    echo -e "${CYAN}"
    echo "╔════════════════════════════════════════════════════════════════╗"
    echo "║         Oracle EBS Deployment Console                         ║"
    echo "║         Web-Enabled Script Framework                          ║"
    echo "╚════════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
}

print_status() {
    echo -e "${GREEN}[✓]${NC} $1"
}

print_error() {
    echo -e "${RED}[✗]${NC} $1"
}

check_python() {
    if command -v python3 &> /dev/null; then
        PYTHON_CMD="python3"
    elif command -v python &> /dev/null; then
        PYTHON_CMD="python"
    else
        print_error "Python 3 is required but not found"
        exit 1
    fi
    
    PYTHON_VERSION=$($PYTHON_CMD --version 2>&1 | cut -d' ' -f2)
    print_status "Python found: $PYTHON_VERSION"
}

setup_venv() {
    if [[ ! -d "$VENV_DIR" ]]; then
        print_status "Creating virtual environment..."
        $PYTHON_CMD -m venv "$VENV_DIR"
    fi
    
    print_status "Activating virtual environment..."
    source "$VENV_DIR/bin/activate"
    
    print_status "Installing dependencies..."
    pip install --quiet --upgrade pip
    pip install --quiet -r "$SCRIPT_DIR/requirements.txt"
}

check_deployment_home() {
    if [[ -z "$DEPLOYMENT_HOME" ]]; then
        echo ""
        print_error "DEPLOYMENT_HOME environment variable is not set!"
        echo ""
        echo "Please set it to your deployment directory:"
        echo "  export DEPLOYMENT_HOME=/path/to/your/deployment"
        echo ""
        echo "Example:"
        echo "  export DEPLOYMENT_HOME=/ADMIN/Oracle/Toolkits/deployStage"
        echo ""
        exit 1
    fi
    
    if [[ ! -d "$DEPLOYMENT_HOME/common/bin" ]]; then
        print_error "DEPLOYMENT_HOME does not contain expected structure"
        echo "Expected: $DEPLOYMENT_HOME/common/bin/commEnv"
        exit 1
    fi
    
    print_status "DEPLOYMENT_HOME: $DEPLOYMENT_HOME"
}

create_logs_dir() {
    mkdir -p "$SCRIPT_DIR/logs"
    print_status "Logs directory ready"
}

start_server() {
    print_status "Starting server on ${HOST}:${PORT}..."
    echo ""
    echo -e "${CYAN}Access the console at: http://localhost:${PORT}${NC}"
    echo ""
    
    cd "$SCRIPT_DIR/backend"
    $PYTHON_CMD -m uvicorn main:app --host "$HOST" --port "$PORT" --reload
}

start_production() {
    print_status "Starting production server on ${HOST}:${PORT}..."
    echo ""
    
    cd "$SCRIPT_DIR/backend"
    gunicorn main:app \
        --bind "${HOST}:${PORT}" \
        --workers 4 \
        --worker-class uvicorn.workers.UvicornWorker \
        --access-logfile "$SCRIPT_DIR/logs/access.log" \
        --error-logfile "$SCRIPT_DIR/logs/error.log"
}

show_help() {
    print_header
    echo "Usage: $0 [COMMAND]"
    echo ""
    echo "Commands:"
    echo "  setup       - Install dependencies and setup environment"
    echo "  start       - Start development server (with auto-reload)"
    echo "  production  - Start production server with gunicorn"
    echo "  help        - Show this help message"
    echo ""
    echo "Environment Variables:"
    echo "  DEPLOYMENT_HOME  - Path to your deployment directory (required)"
    echo "  PORT            - Server port (default: 8080)"
    echo "  HOST            - Server host (default: 0.0.0.0)"
    echo ""
    echo "Examples:"
    echo "  export DEPLOYMENT_HOME=/ADMIN/Oracle/Toolkits/deployStage"
    echo "  $0 setup"
    echo "  $0 start"
    echo ""
}

# ============================================================================
# Main
# ============================================================================

case "${1:-start}" in
    setup)
        print_header
        check_python
        setup_venv
        create_logs_dir
        print_status "Setup complete!"
        echo ""
        echo "To start the server, run:"
        echo "  export DEPLOYMENT_HOME=/path/to/deployment"
        echo "  $0 start"
        ;;
    
    start)
        print_header
        check_python
        check_deployment_home
        setup_venv
        create_logs_dir
        start_server
        ;;
    
    production)
        print_header
        check_python
        check_deployment_home
        setup_venv
        create_logs_dir
        start_production
        ;;
    
    help|--help|-h)
        show_help
        ;;
    
    *)
        print_error "Unknown command: $1"
        show_help
        exit 1
        ;;
esac
