# controller/routes/tokens.py - Complete SSL-compatible version (UPDATED)

from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel, Field, validator
from typing import Optional
import logging
import secrets
import os
import re

from controller.db.db import get_db
from controller.deps import require_authenticated_user, require_admin

logger = logging.getLogger(__name__)

# Create router
router = APIRouter(prefix="/tokens", tags=["tokens"])

# SSL Configuration
SSL_ENABLED = os.getenv("SSL_ENABLED", "true").lower() == "true"

# Valid roles
VALID_ROLES = ["admin", "operator", "viewer", "agent"]


# ==================== Request Models ====================

class CreateTokenRequest(BaseModel):
    token_name: str = Field(..., min_length=2, max_length=100)
    role: str = Field(..., pattern=r'^(admin|operator|viewer|agent)$')
    description: str = Field(default="", max_length=500)
    
    @validator('token_name')
    def validate_token_name(cls, v):
        """Token name must be alphanumeric with hyphens/underscores"""
        if not re.match(r'^[a-zA-Z0-9_-]+$', v):
            raise ValueError('Token name must contain only letters, numbers, hyphens, and underscores')
        return v


class UpdateTokenRequest(BaseModel):
    description: Optional[str] = Field(None, max_length=500)
    role: Optional[str] = Field(None, pattern=r'^(admin|operator|viewer|agent)$')


# ==================== Endpoints ====================

@router.get("")
@router.get("/")
async def list_tokens(
    limit: Optional[int] = None,
    include_revoked: bool = True,
    role: Optional[str] = None,
    token: dict = Depends(require_authenticated_user)
):
    """List all tokens (token values are hidden for security)."""
    try:
        db = get_db()
        tokens = db.list_tokens(limit=limit, include_revoked=include_revoked)
        
        # Filter by role if specified
        if role:
            if role not in VALID_ROLES:
                raise HTTPException(status_code=400, detail=f"Invalid role: {role}")
            tokens = [t for t in tokens if t.get('role') == role]
        
        # Mask sensitive values
        for t in tokens:
            if 'token_value' in t and t['token_value']:
                full = t['token_value']
                t['token_value_preview'] = (
                    f"{full[:10]}...{full[-5:]}" if len(full) > 15 else f"{full[:5]}..."
                )
            t.pop('token_value', None)
            t.pop('token_hash', None)
        
        return {"tokens": tokens, "count": len(tokens), "ssl_enabled": SSL_ENABLED}

    except Exception as e:
        logger.error(f"Error listing tokens: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/{token_name}")
async def get_token(
    token_name: str,
    token: dict = Depends(require_authenticated_user)
):
    """Return metadata for a token (value hidden)."""
    db = get_db()
    token_data = db.get_token(token_name)

    if not token_data:
        raise HTTPException(status_code=404, detail=f"Token '{token_name}' not found")

    token_data.pop("token_hash", None)

    # Mask token value
    if "token_value" in token_data and token_data["token_value"]:
        full = token_data["token_value"]
        token_data["token_value_preview"] = (
            f"{full[:10]}...{full[-5:]}" if len(full) > 15 else f"{full[:5]}..."
        )
    token_data.pop("token_value", None)

    return token_data


@router.post("")
@router.post("/")
async def create_token(
    request: CreateTokenRequest,
    token: dict = Depends(require_admin)
):
    """Create a new API token (admin only)."""
    db = get_db()

    if db.get_token(request.token_name):
        raise HTTPException(status_code=409, detail=f"Token '{request.token_name}' already exists")

    token_value = secrets.token_urlsafe(32)

    try:
        token_data = db.create_token(
            token_name=request.token_name,
            token_value=token_value,
            role=request.role,
            description=request.description
        )

        header = (
            "X-Admin-Token" if request.role in ("admin", "operator", "viewer")
            else "X-Agent-Token"
        )

        return {
            "message": "Token created successfully",
            "token_name": request.token_name,
            "token_value": token_value,   # SHOWN ONCE ONLY
            "role": request.role,
            "ssl_enabled": SSL_ENABLED,
            "created_at": token_data.get('created_at'),
            "warning": "SAVE THIS TOKEN! It will not be shown again.",
            "usage_example": f"curl -H '{header}: {token_value}' https://controller/api/...",
        }

    except Exception as e:
        logger.error(f"Error creating token '{request.token_name}': {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.put("/{token_name}")
async def update_token(
    token_name: str,
    request: UpdateTokenRequest,
    token: dict = Depends(require_admin)
):
    """Update description and/or role (admin only)."""
    db = get_db()

    token_data = db.get_token(token_name)
    if not token_data:
        raise HTTPException(status_code=404, detail=f"Token '{token_name}' not found")

    update_data = {}
    if request.description is not None:
        update_data["description"] = request.description
    if request.role is not None:
        update_data["role"] = request.role

    if not update_data:
        raise HTTPException(status_code=400, detail="No fields to update")

    try:
        db.update_token(
            token_name=token_name,
            description=update_data.get("description", token_data.get("description")),
            role=update_data.get("role", token_data.get("role")),
        )

        updated = db.get_token(token_name)
        updated.pop("token_value", None)
        updated.pop("token_hash", None)

        return {"message": "Token updated", "token": updated}

    except Exception as e:
        logger.error(f"Error updating token '{token_name}': {e}")
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/{token_name}/revoke")
async def revoke_token(
    token_name: str,
    token: dict = Depends(require_admin)
):
    """Revoke a token (soft delete)."""
    db = get_db()
    t = db.get_token(token_name)

    if not t:
        raise HTTPException(status_code=404, detail="Token not found")
    if t.get("revoked") == 1:
        raise HTTPException(status_code=400, detail="Token already revoked")

    db.revoke_token(token_name)
    return {"message": "Token revoked", "token_name": token_name}


@router.post("/{token_name}/restore")
async def restore_token(
    token_name: str,
    token: dict = Depends(require_admin)
):
    db = get_db()
    t = db.get_token(token_name)

    if not t:
        raise HTTPException(status_code=404, detail="Token not found")
    if t.get("revoked") == 0:
        raise HTTPException(status_code=400, detail="Token is not revoked")

    db.restore_token(token_name)
    return {"message": "Token restored", "token_name": token_name}


@router.delete("/{token_name}")
async def delete_token(
    token_name: str,
    token: dict = Depends(require_admin)
):
    """Hard delete a token (cannot be undone)."""
    db = get_db()
    if not db.get_token(token_name):
        raise HTTPException(status_code=404, detail="Token not found")

    db.delete_token(token_name)
    return {"message": "Token permanently deleted", "token_name": token_name}


@router.get("/{token_name}/usage")
async def get_token_usage(
    token_name: str,
    token: dict = Depends(require_authenticated_user)
):
    """Return placeholder usage info."""
    db = get_db()
    t = db.get_token(token_name)

    if not t:
        raise HTTPException(status_code=404, detail="Token not found")

    return {
        "token_name": token_name,
        "role": t.get("role"),
        "created_at": t.get("created_at"),
        "revoked": t.get("revoked") == 1,
        "note": "Usage tracking not implemented yet",
    }
