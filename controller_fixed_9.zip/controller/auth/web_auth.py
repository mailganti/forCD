# controller/auth/web_auth.py

"""
Web authentication with sessions
Supports both development and production
"""

from datetime import datetime, timedelta
from typing import Optional
import secrets
import logging
import bcrypt
from fastapi import HTTPException, Response, Cookie, Request, Depends

logger = logging.getLogger(__name__)

# Password hashing helper functions
def hash_password(password: str) -> str:
    """Hash a password using bcrypt"""
    password_bytes = password.encode('utf-8')
    salt = bcrypt.gensalt()
    hashed = bcrypt.hashpw(password_bytes, salt)
    return hashed.decode('utf-8')

def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify a password against a hash"""
    password_bytes = plain_password.encode('utf-8')
    hashed_bytes = hashed_password.encode('utf-8')
    return bcrypt.checkpw(password_bytes, hashed_bytes)

# Session configuration
SESSION_COOKIE_NAME = "orchestration_session"
SESSION_EXPIRY_HOURS = 24


class SessionManager:
    """Manage user sessions"""
    
    def __init__(self, db):
        self.db = db
    
    def create_session(
        self,
        user_id: int,
        ip_address: str,
        user_agent: str,
        response: Response
    ) -> str:
        """Create new session and set cookie"""
        
        # Generate secure session ID
        session_id = secrets.token_urlsafe(32)
        
        # Calculate expiry
        expires_at = datetime.utcnow() + timedelta(hours=SESSION_EXPIRY_HOURS)
        
        # Store in database
        cursor = self.db.conn.cursor()
        cursor.execute('''
            INSERT INTO sessions (session_id, user_id, expires_at, ip_address, user_agent)
            VALUES (?, ?, ?, ?, ?)
        ''', (session_id, user_id, expires_at.isoformat(), ip_address, user_agent))
        self.db.conn.commit()
        
        # Set secure cookie (SSL always enabled)
        response.set_cookie(
            key=SESSION_COOKIE_NAME,
            value=session_id,
            httponly=True,  # Not accessible via JavaScript (XSS protection)
            secure=True,    # Only send over HTTPS (SSL always on)
            samesite="lax", # CSRF protection
            max_age=SESSION_EXPIRY_HOURS * 3600,
            path="/"
        )
        
        logger.info(f"Session created for user {user_id} (secure cookie)")
        
        return session_id
    
    def get_session(self, session_id: str) -> Optional[dict]:
        """Get session from database"""
        
        if not session_id:
            return None
        
        cursor = self.db.conn.cursor()
        cursor.execute('''
            SELECT s.*, u.username, u.role, u.full_name, u.email
            FROM sessions s
            JOIN users u ON s.user_id = u.user_id
            WHERE s.session_id = ?
            AND datetime(s.expires_at) > datetime('now')
            AND u.is_active = 1
        ''', (session_id,))
        
        row = cursor.fetchone()
        return dict(row) if row else None
    
    def delete_session(self, session_id: str, response: Response):
        """Delete session and clear cookie"""
        
        if not session_id:
            return
        
        cursor = self.db.conn.cursor()
        cursor.execute('DELETE FROM sessions WHERE session_id = ?', (session_id,))
        self.db.conn.commit()
        
        # Clear cookie
        response.delete_cookie(
            key=SESSION_COOKIE_NAME,
            path="/"
        )
        
        logger.info(f"Session deleted: {session_id}")
    
    def cleanup_expired_sessions(self):
        """Remove expired sessions"""
        
        cursor = self.db.conn.cursor()
        cursor.execute("DELETE FROM sessions WHERE datetime(expires_at) <= datetime('now')")
        deleted = cursor.rowcount
        self.db.conn.commit()
        
        if deleted > 0:
            logger.info(f"Cleaned up {deleted} expired sessions")
        
        return deleted


class UserAuth:
    """User authentication"""
    
    def __init__(self, db):
        self.db = db
    
    def verify_password(self, plain_password: str, hashed_password: str) -> bool:
        """Verify password against hash"""
        return verify_password(plain_password, hashed_password)
    
    def hash_password(self, password: str) -> str:
        """Hash password"""
        return hash_password(password)
    
    def authenticate_user(self, username: str, password: str) -> Optional[dict]:
        """Authenticate user with username/password"""
        
        cursor = self.db.conn.cursor()
        cursor.execute('''
            SELECT user_id, username, password_hash, role, full_name, email, auth_method
            FROM users
            WHERE username = ? AND is_active = 1
        ''', (username,))
        
        row = cursor.fetchone()
        
        if not row:
            logger.warning(f"Login attempt for non-existent user: {username}")
            return None
        
        user = dict(row)
        
        # Check auth method
        if user['auth_method'] == 'local':
            # Verify password
            if not self.verify_password(password, user['password_hash']):
                logger.warning(f"Invalid password for user: {username}")
                return None
        
        # Update last login
        cursor.execute('''
            UPDATE users SET last_login = datetime('now')
            WHERE user_id = ?
        ''', (user['user_id'],))
        self.db.conn.commit()
        
        logger.info(f"User authenticated: {username}")
        
        return user
    
    def create_user(
        self,
        username: str,
        password: str,
        role: str = "viewer",
        full_name: str = None,
        email: str = None,
        auth_method: str = "local"
    ) -> dict:
        """Create new user"""
        
        password_hash = self.hash_password(password)
        
        cursor = self.db.conn.cursor()
        cursor.execute('''
            INSERT INTO users (username, password_hash, role, full_name, email, auth_method)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (username, password_hash, role, full_name, email, auth_method))
        
        user_id = cursor.lastrowid
        self.db.conn.commit()
        
        logger.info(f"User created: {username} (role: {role})")
        
        return {
            'user_id': user_id,
            'username': username,
            'role': role
        }
    
    def list_users(self) -> list:
        """List all users"""
        
        cursor = self.db.conn.cursor()
        cursor.execute('''
            SELECT user_id, username, role, full_name, email, created_at, last_login, is_active
            FROM users
            ORDER BY username
        ''')
        
        return [dict(row) for row in cursor.fetchall()]
    
    def change_password(self, username: str, old_password: str, new_password: str) -> bool:
        """Change user password"""
        
        # Verify current password
        user = self.authenticate_user(username, old_password)
        if not user:
            return False
        
        # Update password
        new_hash = self.hash_password(new_password)
        
        cursor = self.db.conn.cursor()
        cursor.execute('''
            UPDATE users SET password_hash = ?
            WHERE user_id = ?
        ''', (new_hash, user['user_id']))
        self.db.conn.commit()
        
        logger.info(f"Password changed for user: {username}")
        
        return True


# Dependencies for route protection
def get_current_user_from_session(
    request: Request,
    session_cookie: Optional[str] = Cookie(None, alias=SESSION_COOKIE_NAME)
) -> Optional[dict]:
    """
    Get current user from session cookie (returns None if not authenticated)
    """
    
    if not session_cookie:
        return None
    
    from controller.db.db import get_db
    db = get_db()
    
    session_manager = SessionManager(db)
    session = session_manager.get_session(session_cookie)
    
    if not session:
        return None
    
    return {
        'user_id': session['user_id'],
        'username': session['username'],
        'role': session['role'],
        'full_name': session['full_name'],
        'email': session['email']
    }


def require_login(
    request: Request,
    session_cookie: Optional[str] = Cookie(None, alias=SESSION_COOKIE_NAME)
) -> dict:
    """
    Require user to be logged in
    Raises 401 if not authenticated
    """
    
    user = get_current_user_from_session(request, session_cookie)
    
    if not user:
        raise HTTPException(
            status_code=401,
            detail="Authentication required"
        )
    
    return user


def require_role(*allowed_roles: str):
    """
    Require specific role for access
    
    Usage:
        @router.get("/admin-only")
        async def admin_page(user: dict = Depends(require_role("admin"))):
            ...
    """
    def role_checker(user: dict = Depends(require_login)) -> dict:
        if user['role'] not in allowed_roles:
            raise HTTPException(
                status_code=403,
                detail=f"Requires one of: {', '.join(allowed_roles)}"
            )
        return user
    
    return role_checker
