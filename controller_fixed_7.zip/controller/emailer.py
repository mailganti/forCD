# controller/emailer.py
"""
Email sending module for the Orchestration System.
Supports SMTP with TLS/SSL and optional authentication.
"""

import os
import ssl
import logging
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Optional, List, Union

logger = logging.getLogger(__name__)

# SMTP Configuration from environment
SMTP_HOST = os.getenv("SMTP_HOST", "localhost")
SMTP_PORT = int(os.getenv("SMTP_PORT", "25"))
SMTP_USER = os.getenv("SMTP_USER", "")
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "")
SMTP_FROM = os.getenv("SMTP_FROM", "orchestration@localhost")
SMTP_USE_TLS = os.getenv("SMTP_USE_TLS", "false").lower() == "true"
SMTP_USE_SSL = os.getenv("SMTP_USE_SSL", "false").lower() == "true"
SMTP_TIMEOUT = int(os.getenv("SMTP_TIMEOUT", "30"))

# For testing/development - log emails instead of sending
EMAIL_DRY_RUN = os.getenv("EMAIL_DRY_RUN", "false").lower() == "true"


def send_email(
    to: Union[str, List[str]],
    subject: str,
    html_body: str,
    text_body: Optional[str] = None,
    from_addr: Optional[str] = None,
    cc: Optional[Union[str, List[str]]] = None,
    bcc: Optional[Union[str, List[str]]] = None,
    reply_to: Optional[str] = None,
) -> bool:
    """
    Send an email with HTML content.
    
    Args:
        to: Recipient email address(es)
        subject: Email subject
        html_body: HTML content of the email
        text_body: Plain text fallback (auto-generated if not provided)
        from_addr: Sender address (defaults to SMTP_FROM)
        cc: CC recipients
        bcc: BCC recipients
        reply_to: Reply-To address
        
    Returns:
        True if email was sent successfully, False otherwise
    """
    # Normalize recipients to lists
    if isinstance(to, str):
        to = [to]
    if isinstance(cc, str):
        cc = [cc]
    if isinstance(bcc, str):
        bcc = [bcc]
    
    # Filter empty addresses
    to = [addr.strip() for addr in to if addr and addr.strip()]
    cc = [addr.strip() for addr in (cc or []) if addr and addr.strip()]
    bcc = [addr.strip() for addr in (bcc or []) if addr and addr.strip()]
    
    if not to:
        logger.warning("No recipients specified, skipping email")
        return False
    
    sender = from_addr or SMTP_FROM
    
    # Build message
    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = sender
    msg["To"] = ", ".join(to)
    
    if cc:
        msg["Cc"] = ", ".join(cc)
    if reply_to:
        msg["Reply-To"] = reply_to
    
    # Add plain text part (fallback)
    if not text_body:
        # Strip HTML for plain text version
        import re
        text_body = re.sub(r'<[^>]+>', '', html_body)
        text_body = re.sub(r'\s+', ' ', text_body).strip()
    
    msg.attach(MIMEText(text_body, "plain", "utf-8"))
    msg.attach(MIMEText(html_body, "html", "utf-8"))
    
    # All recipients for SMTP
    all_recipients = to + cc + bcc
    
    # Dry run mode - just log
    if EMAIL_DRY_RUN:
        logger.info(f"[DRY RUN] Email would be sent:")
        logger.info(f"  To: {', '.join(to)}")
        logger.info(f"  Subject: {subject}")
        logger.info(f"  From: {sender}")
        return True
    
    try:
        # Create SSL context
        context = ssl.create_default_context()
        
        if SMTP_USE_SSL:
            # SSL from the start (port 465)
            server = smtplib.SMTP_SSL(SMTP_HOST, SMTP_PORT, timeout=SMTP_TIMEOUT, context=context)
        else:
            # Regular SMTP, optionally with STARTTLS
            server = smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=SMTP_TIMEOUT)
            if SMTP_USE_TLS:
                server.starttls(context=context)
        
        # Authenticate if credentials provided
        if SMTP_USER and SMTP_PASSWORD:
            server.login(SMTP_USER, SMTP_PASSWORD)
        
        # Send email
        server.sendmail(sender, all_recipients, msg.as_string())
        server.quit()
        
        logger.info(f"Email sent to {', '.join(to)}: {subject}")
        return True
        
    except smtplib.SMTPAuthenticationError as e:
        logger.error(f"SMTP authentication failed: {e}")
        return False
    except smtplib.SMTPRecipientsRefused as e:
        logger.error(f"Recipients refused: {e}")
        return False
    except smtplib.SMTPException as e:
        logger.error(f"SMTP error sending email: {e}")
        return False
    except Exception as e:
        logger.error(f"Failed to send email: {e}")
        return False


def send_approval_request(
    approver_email: str,
    requestor: str,
    requestor_email: str,
    workflow_id: str,
    script_id: str,
    targets: List[str],
    reason: str,
    dashboard_url: str,
    ttl_minutes: int = 60,
) -> bool:
    """
    Send approval request email to approver.
    """
    html_content = f"""
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <h2 style="color: #1e3a5f;">Workflow Approval Required</h2>
        <p>A new workflow has been submitted and requires your approval.</p>
        
        <table style="width: 100%; border-collapse: collapse; margin: 20px 0;">
            <tr style="background: #f8f9fa;">
                <td style="padding: 10px; border: 1px solid #dee2e6; font-weight: bold;">Workflow ID</td>
                <td style="padding: 10px; border: 1px solid #dee2e6; font-family: monospace;">{workflow_id}</td>
            </tr>
            <tr>
                <td style="padding: 10px; border: 1px solid #dee2e6; font-weight: bold;">Requestor</td>
                <td style="padding: 10px; border: 1px solid #dee2e6;">{requestor}</td>
            </tr>
            <tr style="background: #f8f9fa;">
                <td style="padding: 10px; border: 1px solid #dee2e6; font-weight: bold;">Requestor Email</td>
                <td style="padding: 10px; border: 1px solid #dee2e6;"><a href="mailto:{requestor_email}">{requestor_email}</a></td>
            </tr>
            <tr>
                <td style="padding: 10px; border: 1px solid #dee2e6; font-weight: bold;">Script</td>
                <td style="padding: 10px; border: 1px solid #dee2e6; font-family: monospace;">{script_id}</td>
            </tr>
            <tr style="background: #f8f9fa;">
                <td style="padding: 10px; border: 1px solid #dee2e6; font-weight: bold;">Target Agents</td>
                <td style="padding: 10px; border: 1px solid #dee2e6;">{', '.join(targets)}</td>
            </tr>
            <tr>
                <td style="padding: 10px; border: 1px solid #dee2e6; font-weight: bold;">Reason</td>
                <td style="padding: 10px; border: 1px solid #dee2e6;">{reason}</td>
            </tr>
            <tr style="background: #f8f9fa;">
                <td style="padding: 10px; border: 1px solid #dee2e6; font-weight: bold;">Expires In</td>
                <td style="padding: 10px; border: 1px solid #dee2e6;">{ttl_minutes} minutes</td>
            </tr>
        </table>
        
        <p style="margin: 20px 0;">
            <a href="{dashboard_url}" style="background: #0ea5e9; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
                Open Dashboard to Approve
            </a>
        </p>
        
        <p style="color: #6b7280; font-size: 12px; margin-top: 30px;">
            This is an automated message from the Orchestration System.<br>
            Requested by: {requestor}
        </p>
    </div>
    """
    
    return send_email(
        to=approver_email,
        subject=f"[Action Required] Workflow Approval: {script_id} - {requestor}",
        html_body=html_content,
        reply_to=requestor_email,
    )
