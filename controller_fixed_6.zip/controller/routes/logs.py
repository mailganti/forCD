import os
import asyncio
from fastapi import APIRouter, HTTPException, Query
from fastapi.responses import FileResponse, PlainTextResponse, StreamingResponse

router = APIRouter(prefix="/logs", tags=["logs"])

# --------------------------------------------------------------------
# SAFE DIRECTORIES YOU ALLOW LOG ACCESS TO
# Add more if needed later
# --------------------------------------------------------------------
SAFE_LOG_ROOTS = [
    "/ADMIN/",
    "/u01/",
    "/u01t/",
    "/u01python/",
    "/opt/",
]


def is_safe_path(path: str) -> bool:
    """Return True only if path is inside an allowed log root."""
    real = os.path.realpath(path)
    for root in SAFE_LOG_ROOTS:
        if real.startswith(os.path.realpath(root)):
            return True
    return False


def normalize_path(path: str) -> str:
    """Fix // double-slash, remove ANSI, return real canonical path."""
    if not path:
        return path

    # Remove ANSI color codes
    import re
    clean = re.sub(r"\x1b\[[0-9;]*m", "", path)

    # Replace duplicate slashes
    while "//" in clean:
        clean = clean.replace("//", "/")

    return clean


# --------------------------------------------------------------------
# 1. Download / View Full Logfile
# --------------------------------------------------------------------
@router.get("/file")
async def get_log_file(path: str = Query(...)):
    """Return the full logfile as a file download."""
    path = normalize_path(path)
    real = os.path.realpath(path)

    if not is_safe_path(real):
        raise HTTPException(status_code=403, detail="Access Denied: logfile outside allowed roots")

    if not os.path.exists(real):
        raise HTTPException(status_code=404, detail=f"Log file not found: {real}")

    return FileResponse(real, filename=os.path.basename(real))


# --------------------------------------------------------------------
# 2. Tail -f Style Live Log Streaming
# --------------------------------------------------------------------
@router.get("/tail")
async def tail_log_file(path: str = Query(...)):
    """Stream live updates of a logfile (like tail -f)."""
    path = normalize_path(path)
    real = os.path.realpath(path)

    if not is_safe_path(real):
        raise HTTPException(status_code=403, detail="Access Denied: logfile outside allowed roots")

    if not os.path.exists(real):
        raise HTTPException(status_code=404, detail=f"Log file not found: {real}")

    async def event_stream():
        with open(real, "r") as f:
            # Go to end of file
            f.seek(0, os.SEEK_END)

            while True:
                line = f.readline()
                if line:
                    yield line
                else:
                    await asyncio.sleep(0.5)

    return StreamingResponse(event_stream(), media_type="text/plain")
