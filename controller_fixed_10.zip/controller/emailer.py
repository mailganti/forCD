# controller/emailer.py
"""
Email sending module for the Orchestration System.
Uses system sendmail command for delivery.
"""

import os
import logging
import subprocess
from typing import Optional, List, Union

logger = logging.getLogger(__name__)

# Configuration
SMTP_FROM = os.getenv("SMTP_FROM", "orchestration@localhost")
EMAIL_DRY_RUN = os.getenv("EMAIL_DRY_RUN", "false").lower() == "true"

# Path to sendmail (common locations)
SENDMAIL_PATH = os.getenv("SENDMAIL_PATH", "/usr/sbin/sendmail")

# Alternative: use mail/mailx command instead of sendmail
USE_MAIL_CMD = os.getenv("USE_MAIL_CMD", "false").lower() == "true"
MAIL_CMD = os.getenv("MAIL_CMD", "mail")  # or "mailx"

logger.info(f"[EMAILER] Config: SMTP_FROM={SMTP_FROM}, SENDMAIL_PATH={SENDMAIL_PATH}, USE_MAIL_CMD={USE_MAIL_CMD}, DRY_RUN={EMAIL_DRY_RUN}")


def send_email(
    to: Union[str, List[str]],
    subject: str,
    html_body: str,
    text_body: Optional[str] = None,
    from_addr: Optional[str] = None,
    cc: Optional[Union[str, List[str]]] = None,
    reply_to: Optional[str] = None,
) -> bool:
    """
    Send an email using system sendmail command.
    
    Args:
        to: Recipient email address(es)
        subject: Email subject
        html_body: HTML content of the email
        text_body: Plain text fallback (auto-generated if not provided)
        from_addr: Sender address (defaults to SMTP_FROM)
        cc: CC recipients
        reply_to: Reply-To address
        
    Returns:
        True if email was sent successfully, False otherwise
    """
    import re
    
    # Normalize recipients to lists
    if isinstance(to, str):
        to = [to]
    if isinstance(cc, str):
        cc = [cc]
    
    # Filter empty addresses
    to = [addr.strip() for addr in to if addr and addr.strip()]
    cc = [addr.strip() for addr in (cc or []) if addr and addr.strip()]
    
    if not to:
        logger.warning("No recipients specified, skipping email")
        return False
    
    sender = from_addr or SMTP_FROM
    
    # Generate plain text if not provided
    if not text_body:
        text_body = re.sub(r'<[^>]+>', '', html_body)
        text_body = re.sub(r'\s+', ' ', text_body).strip()
    
    # Build MIME message manually
    boundary = "----=_Part_0_123456789"
    
    headers = [
        f"From: {sender}",
        f"To: {', '.join(to)}",
        f"Subject: {subject}",
        "MIME-Version: 1.0",
        f'Content-Type: multipart/alternative; boundary="{boundary}"',
    ]
    
    if cc:
        headers.append(f"Cc: {', '.join(cc)}")
    if reply_to:
        headers.append(f"Reply-To: {reply_to}")
    
    # Build message body
    message_parts = [
        "\n".join(headers),
        "",
        f"--{boundary}",
        "Content-Type: text/plain; charset=utf-8",
        "Content-Transfer-Encoding: 8bit",
        "",
        text_body,
        "",
        f"--{boundary}",
        "Content-Type: text/html; charset=utf-8",
        "Content-Transfer-Encoding: 8bit",
        "",
        html_body,
        "",
        f"--{boundary}--",
    ]
    
    full_message = "\n".join(message_parts)
    
    # All recipients
    all_recipients = to + cc
    
    # Dry run mode
    if EMAIL_DRY_RUN:
        logger.info(f"[DRY RUN] Email would be sent:")
        logger.info(f"  To: {', '.join(to)}")
        logger.info(f"  Subject: {subject}")
        logger.info(f"  From: {sender}")
        return True
    
    try:
        # Debug logging
        logger.info(f"[EMAIL DEBUG] SENDMAIL_PATH={SENDMAIL_PATH}, exists={os.path.exists(SENDMAIL_PATH)}")
        logger.info(f"[EMAIL DEBUG] USE_MAIL_CMD={USE_MAIL_CMD}, MAIL_CMD={MAIL_CMD}")
        logger.info(f"[EMAIL DEBUG] Recipients: {all_recipients}")
        logger.info(f"[EMAIL DEBUG] From: {sender}")
        
        # Option 1: Use mail/mailx command (set USE_MAIL_CMD=true)
        if USE_MAIL_CMD:
            for recipient in all_recipients:
                # Build mail command - adjust based on your mail variant
                cmd = [MAIL_CMD, "-s", subject, recipient]
                logger.info(f"[EMAIL DEBUG] Running: {' '.join(cmd)}")
                
                proc = subprocess.Popen(
                    cmd,
                    stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE
                )
                # Send plain text body via stdin
                stdout, stderr = proc.communicate(input=text_body.encode('utf-8'))
                
                logger.info(f"[EMAIL DEBUG] mail returncode={proc.returncode}")
                if stderr:
                    logger.info(f"[EMAIL DEBUG] mail stderr: {stderr.decode()}")
                
                if proc.returncode != 0:
                    logger.error(f"mail command failed for {recipient}: {stderr.decode()}")
                    return False
            
            logger.info(f"Email sent via {MAIL_CMD} to {', '.join(to)}: {subject}")
            return True
        
        # Option 2: Use sendmail
        elif os.path.exists(SENDMAIL_PATH):
            cmd = [SENDMAIL_PATH, "-t", "-oi"]
            logger.info(f"[EMAIL DEBUG] Running: {' '.join(cmd)}")
            proc = subprocess.Popen(
                cmd,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            stdout, stderr = proc.communicate(input=full_message.encode('utf-8'))
            
            logger.info(f"[EMAIL DEBUG] sendmail returncode={proc.returncode}")
            if stdout:
                logger.info(f"[EMAIL DEBUG] sendmail stdout: {stdout.decode()}")
            if stderr:
                logger.info(f"[EMAIL DEBUG] sendmail stderr: {stderr.decode()}")
            
            if proc.returncode == 0:
                logger.info(f"Email sent via sendmail to {', '.join(to)}: {subject}")
                return True
            else:
                logger.error(f"sendmail failed with code {proc.returncode}: {stderr.decode()}")
                return False
        
        # Fallback to mail command
        else:
            # Use mail command with recipients
            for recipient in all_recipients:
                cmd = ["mail", "-s", subject, "-a", f"From: {sender}"]
                if reply_to:
                    cmd.extend(["-a", f"Reply-To: {reply_to}"])
                cmd.append(recipient)
                
                proc = subprocess.Popen(
                    cmd,
                    stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE
                )
                # For mail command, send HTML as body (limited support)
                stdout, stderr = proc.communicate(input=html_body.encode('utf-8'))
                
                if proc.returncode != 0:
                    logger.error(f"mail command failed for {recipient}: {stderr.decode()}")
                    return False
            
            logger.info(f"Email sent via mail to {', '.join(to)}: {subject}")
            return True
            
    except FileNotFoundError as e:
        logger.error(f"sendmail/mail command not found: {e}")
        return False
    except Exception as e:
        logger.error(f"Failed to send email: {e}")
        return False
