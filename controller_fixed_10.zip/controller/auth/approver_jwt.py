# controller/auth/approver_jwt.py
"""
JWT token creation and verification for workflow approvers.
Used for the re-execution approval flow.
"""

import os
import jwt
from datetime import datetime, timedelta

APPROVER_JWT_SECRET = os.getenv("APPROVER_JWT_SECRET", "change-me")
APPROVER_JWT_ALGO = os.getenv("APPROVER_JWT_ALGO", "HS256")


def create_approver_jwt(subject: str, role: str = "approver", ttl_minutes: int = 60) -> str:
    """
    Create a JWT token for an approver.
    
    Args:
        subject: Username or identifier
        role: Role (approver or admin)
        ttl_minutes: Token validity in minutes
    
    Returns:
        Encoded JWT string
    """
    now = datetime.utcnow()
    payload = {
        "sub": subject,
        "role": role,
        "iat": now,
        "exp": now + timedelta(minutes=ttl_minutes)
    }
    return jwt.encode(payload, APPROVER_JWT_SECRET, algorithm=APPROVER_JWT_ALGO)


def verify_approver_jwt(token: str) -> dict:
    """
    Verify and decode an approver JWT.
    
    Args:
        token: JWT string
    
    Returns:
        Decoded payload dict
    
    Raises:
        jwt.ExpiredSignatureError: Token expired
        jwt.InvalidTokenError: Invalid token
    """
    return jwt.decode(token, APPROVER_JWT_SECRET, algorithms=[APPROVER_JWT_ALGO])
