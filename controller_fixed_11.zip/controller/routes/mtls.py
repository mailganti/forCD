import ssl
from ssl import DER_cert_to_PEM_cert

class MTLSMiddleware:
    def __init__(self, app):
        self.app = app

    async def __call__(self, scope, receive, send):

        # Only HTTP/WebSocket connections have SSL info
        if scope["type"] in ("http", "websocket"):

            ssl_info = scope.get("extensions", {}).get("ssl", {})
            ssl_obj = ssl_info.get("ssl_object")

            if ssl_obj:
                try:
                    # Extract certificate in DER form
                    der = ssl_obj.getpeercert(binary_form=True)

                    if der:
                        pem = DER_cert_to_PEM_cert(der)

                        decoded = ssl._ssl._test_decode_cert(pem)

                        scope["client_cert"] = pem
                        scope["client_cert_subject"] = decoded.get("subject", [])
                        scope["client_cert_issuer"] = decoded.get("issuer", [])
                        scope["client_cert_serial"] = decoded.get("serialNumber")
                    else:
                        scope["client_cert"] = None

                except Exception:
                    scope["client_cert"] = None

        return await self.app(scope, receive, send)
