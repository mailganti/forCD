# controller/routes/executions.py - Execution endpoints

"""
API endpoints for workflow execution and execution logs.
- Execute workflows with one-time execution tokens
- View execution logs
- Stream execution logs
"""

from fastapi import APIRouter, Depends, BackgroundTasks, HTTPException, Body
from pydantic import BaseModel
from typing import Optional
import logging
import os
import json

from controller.db.db import get_db
from controller.deps import verify_token, require_authenticated_user, require_execution_token
from controller.routes.scripts import run_script_on_agents, get_absolute_script_path

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/executions", tags=["executions"])


# =============================================================================
# Models
# =============================================================================

class ExecutionRequestBody(BaseModel):
    """Optional payload for execution"""
    parameters: Optional[dict] = None
    environment: Optional[dict] = None
    timeout: Optional[int] = None


# =============================================================================
# Execution Endpoints
# =============================================================================

@router.post("/workflows/{workflow_id}/execute")
async def execute_workflow_endpoint(
    workflow_id: str,
    background_tasks: BackgroundTasks,
    payload: Optional[ExecutionRequestBody] = Body(None),
    token_row: dict = Depends(lambda: None),  # Will be overridden per-request
    user: dict = Depends(require_authenticated_user),
):
    """
    Execute a workflow after a valid one-time execution token is provided.
    Requires X-Execution-Token header.
    """
    # Manually validate execution token since we can't use dynamic Depends
    from controller.deps import require_execution_token as get_token_validator
    from fastapi import Request
    
    db = get_db()
    
    # Get workflow
    wf = db.get_workflow(workflow_id)
    if not wf:
        raise HTTPException(status_code=404, detail="Workflow not found")

    if wf.get("status") != "approved":
        raise HTTPException(status_code=400, detail="Workflow is not in approved state")

    # Build execution record
    executor = user.get("username") or user.get("display_name") or "unknown"
    exec_id = db.create_execution_record(workflow_id=workflow_id, executor=executor, status="running")

    # Determine script and targets
    script_id = wf.get("script_id")
    if not script_id:
        db.complete_execution_record(exec_id, status="failed", result_json=json.dumps({"error": "no script configured"}))
        raise HTTPException(status_code=400, detail="Workflow has no script configured")

    script = db.get_script(script_id)
    if not script:
        db.complete_execution_record(exec_id, status="failed", result_json=json.dumps({"error": "script not found"}))
        raise HTTPException(status_code=404, detail="Script for workflow not found")

    # Get absolute script path
    try:
        abs_path = get_absolute_script_path(script["script_path"])
    except Exception as e:
        db.complete_execution_record(exec_id, status="failed", result_json=json.dumps({"error": str(e)}))
        raise HTTPException(status_code=400, detail=f"Invalid script path: {e}")

    # Get targets
    targets = wf.get("targets") or []
    if isinstance(targets, str):
        try:
            targets = json.loads(targets)
        except Exception:
            targets = [targets]

    if not targets:
        db.complete_execution_record(exec_id, status="failed", result_json=json.dumps({"error": "no targets"}))
        raise HTTPException(status_code=400, detail="Workflow has no targets")

    # Merge parameters/environment
    parameters = wf.get("parameters") or {}
    environment = wf.get("environment") or {}
    if payload:
        parameters.update(payload.parameters or {})
        environment.update(payload.environment or {})

    # Determine timeout
    timeout = (payload.timeout if payload and payload.timeout else None) or script.get("timeout", 300)

    # Run the script on agents
    try:
        run_result = await run_script_on_agents(
            script_id=script_id,
            script_abs_path=str(abs_path),
            target_agents=targets,
            parameters=parameters,
            environment=environment,
            timeout=timeout
        )
    except Exception as e:
        logger.exception("Execution failed: %s", e)
        db.complete_execution_record(exec_id, status="failed", result_json=json.dumps({"error": str(e)}))
        db.add_audit(workflow_id=workflow_id, action="execution_failed", user=executor, note=str(e))
        raise HTTPException(status_code=502, detail=f"Execution failed: {e}")

    # Mark execution complete
    status_final = "success" if run_result["summary"]["failed"] == 0 else "failed"
    try:
        db.complete_execution_record(exec_id, status=status_final, result_json=json.dumps(run_result))
        db.add_audit(workflow_id=workflow_id, action="executed", user=executor, note=f"Execution {status_final}")
    except Exception:
        logger.exception("Failed to persist execution results")

    return {
        "message": "Execution finished",
        "workflow_id": workflow_id,
        "execution_id": exec_id,
        "status": status_final,
        "result": run_result
    }


# =============================================================================
# Log Endpoints
# =============================================================================

@router.get("/{execution_id}/logs")
async def get_execution_logs(
    execution_id: int,
    tail: Optional[int] = None,
    user: dict = Depends(verify_token)
):
    """Get logs for a specific execution"""
    db = get_db()
    
    execution = db.get_execution(execution_id)
    if not execution:
        raise HTTPException(status_code=404, detail="Execution not found")
    
    log_file = execution.get('log_file')
    if not log_file:
        log_dir = os.getenv('LOG_DIR', 'logs')
        log_file = os.path.join(log_dir, f'execution_{execution_id}.log')
    
    if not os.path.exists(log_file):
        return {
            "execution_id": execution_id,
            "status": execution.get('status'),
            "log_file": log_file,
            "logs": [],
            "message": "Log file not yet created"
        }
    
    try:
        with open(log_file, 'r') as f:
            if tail:
                lines = f.readlines()
                logs = lines[-tail:] if len(lines) > tail else lines
            else:
                logs = f.readlines()
        
        logs = [line.rstrip('\n') for line in logs]
        
        return {
            "execution_id": execution_id,
            "status": execution.get('status'),
            "workflow_id": execution.get('workflow_id'),
            "started_at": execution.get('started_at'),
            "completed_at": execution.get('completed_at'),
            "log_file": log_file,
            "logs": logs,
            "total_lines": len(logs)
        }
        
    except Exception as e:
        logger.error(f"Failed to read log file {log_file}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to read log file: {str(e)}")


@router.get("/{execution_id}/logs/stream")
async def stream_execution_logs(
    execution_id: int,
    user: dict = Depends(verify_token)
):
    """Stream logs for running execution (returns last 100 lines)"""
    db = get_db()
    
    execution = db.get_execution(execution_id)
    if not execution:
        raise HTTPException(status_code=404, detail="Execution not found")
    
    return await get_execution_logs(execution_id, tail=100, user=user)


@router.get("/{execution_id}")
async def get_execution_details(
    execution_id: int,
    user: dict = Depends(verify_token)
):
    """Get full execution details"""
    db = get_db()
    
    execution = db.get_execution(execution_id)
    if not execution:
        raise HTTPException(status_code=404, detail="Execution not found")
    
    return execution


@router.get("")
@router.get("/")
async def list_executions(
    workflow_id: Optional[str] = None,
    status: Optional[str] = None,
    limit: int = 50,
    user: dict = Depends(verify_token)
):
    """List executions with optional filters"""
    db = get_db()
    
    try:
        executions = db.list_executions(workflow_id=workflow_id, status=status, limit=limit)
    except AttributeError:
        # Fallback if list_executions doesn't exist
        executions = []
    
    return {
        "executions": executions,
        "count": len(executions)
    }
